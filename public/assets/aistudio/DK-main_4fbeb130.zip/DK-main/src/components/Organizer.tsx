import React, { useEffect, useMemo, useState } from 'react';
import { useApp } from '../lib/store';
import { PERSONAS, ROOMS } from '../lib/seed';
import { canManage, findRoomConflicts } from '../lib/logic';
import { Avatar, CategoryBadge, EmptyState, Icon, Mono, SectionHeader } from './UI';
import {
  buildCSV,
  dayLabel,
  downloadFile,
  isoDate,
  longDate,
  minutesFromTime,
  pct,
  relativeTime,
} from '../lib/utils';
import type { EventItem, Person } from '../types';

type GuestTab = 'all' | 'checked' | 'not' | 'waitlist' | 'screening';

export default function Organizer() {
  const app = useApp();
  const manageable = app.state.events.filter(
    (e) => e.approvalStatus === 'approved' && canManage(e, app.persona),
  );
  const sorted = manageable
    .slice()
    .sort((a, b) =>
      `${a.past ? 1 : 0}${a.date}${a.startTime}`.localeCompare(`${b.past ? 1 : 0}${b.date}${b.startTime}`),
    );
  const [selectedId, setSelectedId] = useState('');
  const current =
    sorted.find((e) => e.id === selectedId) ??
    sorted.find((e) => e.id === app.organizerEventId) ??
    sorted[0];

  const [tab, setTab] = useState<GuestTab>('all');
  const [search, setSearch] = useState('');
  const [scanning, setScanning] = useState(false);
  const [lastScan, setLastScan] = useState<{ name: string; programme: string; hash: string } | null>(null);
  const [broadcastText, setBroadcastText] = useState('');

  useEffect(() => {
    setLastScan(null);
    setTab('all');
    setSearch('');
  }, [current?.id]);

  const attendees: Person[] = current?.attendees ?? [];
  const checkedIn = attendees.filter((a) => current?.checkIns[a.id]);
  const pending = attendees.filter((a) => !current?.checkIns[a.id]);
  const ticket = current ? app.myTicket(current.id) : undefined;
  const confirmed4h = current
    ? Math.min(
        current.registeredCount,
        Math.round(current.registeredCount * (current.past ? 0.98 : 0.82)) +
          (ticket?.confirmedAttendance4h ? 1 : 0),
      )
    : 0;
  const turnout = current ? pct(checkedIn.length, Math.max(current.registeredCount, 1)) : 0;

  const rows = useMemo(() => {
    return attendees.filter((a) => {
      if (!search.trim()) return true;
      const q = search.toLowerCase();
      return `${a.name} ${a.programme} ${a.telegram}`.toLowerCase().includes(q);
    });
  }, [attendees, search]);

  const visibleRows = rows.filter((a) => {
    if (tab === 'checked') return Boolean(current?.checkIns[a.id]);
    if (tab === 'not') return !current?.checkIns[a.id];
    if (tab === 'waitlist' || tab === 'screening') return false;
    return true;
  });

  const screeningTickets = current
    ? app.state.tickets.filter((t) => t.eventId === current.id && t.screeningStatus === 'pending')
    : [];

  const scanNext = () => {
    if (!current) return;
    if (pending.length === 0) {
      app.pushToast({
        tone: 'info',
        title: 'Every cached pass is already scanned',
        message: 'The offline cache is empty for this event. Manual guest check-in is still available below.',
      });
      return;
    }
    const person = pending[Math.floor(Math.random() * pending.length)];
    setScanning(true);
    window.setTimeout(() => {
      app.checkInPerson(current.id, person.id);
      setLastScan({
        name: person.name,
        programme: person.programmeShort,
        hash: `UDEA-PASS-${person.id.replace(/\D/g, '').slice(-4) || '0000'}-${person.id
          .slice(-2)
          .toUpperCase()}`,
      });
      setScanning(false);
    }, 720);
  };

  const exportCSV = () => {
    if (!current) return;
    const header = ['Student ID', 'Full Name', 'Programme', 'Telegram', 'Status', 'Check-In Timestamp'];
    const body = current.attendees.map((a, i) => {
      const checkAt = current.checkIns[a.id];
      const id = a.self ? app.persona.studentId : `UDEA-24-${1000 + i}`;
      return [
        id,
        a.name,
        a.programme,
        a.telegram,
        checkAt ? 'Checked In' : 'Not Arrived',
        checkAt ? new Date(checkAt).toLocaleString() : '',
      ];
    });
    current.waitlistRoster.forEach((w) => {
      body.push([w.studentId, w.name, w.programme, w.telegram, 'Waitlist', '']);
    });
    downloadFile(`udea_attendance_${current.id}_${isoDate()}.csv`, buildCSV([header, ...body]), 'text/csv;charset=utf-8');
    app.pushToast({
      tone: 'success',
      title: 'CSV attendance report downloaded',
      message: `${body.length} rows exported for university reporting.`,
    });
  };

  const pendingApprovals = app.state.events.filter((e) => e.approvalStatus === 'pending_room_approval');

  return (
    <div className="organizer">
      <SectionHeader
        icon="shield"
        title="Organizer Studio & Campus Admin"
        subtitle="Live turnout telemetry, offline QR check-in, Telegram broadcasts and the room approval queue."
        action={
          <button className="btn btn-ghost btn-sm" onClick={() => app.setView('studio')}>
            <Icon name="plus" size={14} /> Host new event
          </button>
        }
      />

      {sorted.length === 0 ? (
        <EmptyState
          icon="shield"
          title="You are not hosting an event yet"
          message="Create a peer meetup or an official event and the organizer toolkit unlocks automatically for the host."
          action={
            <button className="btn btn-primary" onClick={() => app.setView('studio')}>
              Open Host Event Studio
            </button>
          }
        />
      ) : (
        <>
          <div className="org-toolbar">
            <label className="org-select">
              <span className="mono subtle">SELECT HOSTED EVENT</span>
              <select value={current?.id ?? ''} onChange={(e) => setSelectedId(e.target.value)}>
                {sorted.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.title} — {dayLabel(e.date)}
                  </option>
                ))}
              </select>
            </label>
            <div className="org-toolbar-facts">
              <CategoryBadge category={current!.category} />
              <Mono>{dayLabel(current!.date)} • {current!.startTime}–{current!.endTime}</Mono>
              <Mono>{ROOMS.find((r) => r.id === current!.roomId)?.code}</Mono>
            </div>
          </div>

          <div className="metrics-row">
            <div className="metric-tile">
              <Mono>REGISTERED</Mono>
              <strong>{current!.registeredCount}</strong>
              <span>of {current!.capacity} seats</span>
            </div>
            <div className="metric-tile">
              <Mono>4H CONFIRMED</Mono>
              <strong>{confirmed4h}</strong>
              <span>Telegram bot checks</span>
            </div>
            <div className="metric-tile">
              <Mono>CHECKED IN</Mono>
              <strong>{checkedIn.length}</strong>
              <span>live at the door</span>
            </div>
            <div className="metric-tile">
              <Mono>WAITLIST</Mono>
              <strong>{current!.waitlistCount}</strong>
              <span>in queue</span>
            </div>
            <div className="metric-tile highlight">
              <Mono>TURNOUT</Mono>
              <strong>{turnout}%</strong>
              <span className="capacity-track tiny">
                <span className="capacity-fill cap-open" style={{ width: `${turnout}%` }} />
              </span>
            </div>
          </div>

          <div className="org-grid">
            <section className="card scanner-card">
              <div className="panel-head">
                <h2><Icon name="camera" size={17} /> Offline QR check-in</h2>
                <span className="cache-badge">
                  <i /> Offline Crypto-Hash Cache Ready ({current!.registeredCount}/{current!.registeredCount} passes stored)
                </span>
              </div>

              <div className={`scanner-view ${scanning ? 'is-scanning' : ''}`}>
                <div className="scanner-grid" />
                <span className="scanner-corner tl" />
                <span className="scanner-corner tr" />
                <span className="scanner-corner bl" />
                <span className="scanner-corner br" />
                <span className="scanner-laser" />
                <div className="scanner-center">
                  <Icon name="qr" size={64} />
                  <span className="mono">{scanning ? 'VALIDATING HASH…' : 'POINT AT A STUDENT PASS'}</span>
                </div>
              </div>

              <div className="scanner-actions">
                <button className="btn btn-primary" onClick={scanNext} disabled={scanning}>
                  <Icon name="qr" size={15} /> {scanning ? 'Scanning…' : 'Simulate Next Student QR Scan'}
                </button>
                <span className="mono subtle">{pending.length} NOT YET SCANNED</span>
              </div>

              {lastScan && (
                <div className="scan-result">
                  <span className="scan-check"><Icon name="check" size={16} /></span>
                  <div>
                    <strong>{lastScan.name}</strong>
                    <span>{lastScan.programme} · {lastScan.hash}</span>
                  </div>
                  <span className="badge badge-success">VALID PASS</span>
                </div>
              )}

              <div className="scanner-note mono">
                SCANNER RUNS FROM DEVICE MEMORY · NO SIGNAL REQUIRED · SYNC QUEUES ON RECONNECT
              </div>
            </section>

            <section className="card broadcast-card">
              <div className="panel-head">
                <h2><Icon name="telegram" size={17} /> Instant Telegram broadcast</h2>
                <Mono>@udea_pulse_bot</Mono>
              </div>
              <textarea
                rows={4}
                value={broadcastText}
                onChange={(e) => setBroadcastText(e.target.value)}
                placeholder="e.g. We moved from Room 204 to the Grand Assembly Hall due to high demand!"
              />
              <div className="broadcast-actions">
                <button
                  className="btn btn-primary"
                  disabled={broadcastText.trim().length < 4}
                  onClick={() => {
                    if (!current) return;
                    app.broadcast(current.id, broadcastText);
                    setBroadcastText('');
                  }}
                >
                  <Icon name="telegram" size={15} /> Send via Telegram Bot to {current!.registeredCount} attendees
                </button>
                <button className="btn btn-ghost" onClick={exportCSV}>
                  <Icon name="download" size={15} /> Export CSV
                </button>
              </div>
              <div className="broadcast-history">
                <span className="mono subtle">RECENT BROADCASTS</span>
                {app.state.broadcasts.filter((b) => b.eventId === current!.id).length === 0 ? (
                  <p className="hint">No messages sent for this event yet.</p>
                ) : (
                  app.state.broadcasts
                    .filter((b) => b.eventId === current!.id)
                    .map((b) => (
                      <div key={b.id} className="broadcast-row">
                        <Icon name="telegram" size={13} />
                        <span>{b.text}</span>
                        <Mono>{b.recipients} SENT · {relativeTime(b.at)}</Mono>
                      </div>
                    ))
                )}
              </div>
            </section>
          </div>

          <section className="card guest-card">
            <div className="panel-head">
              <h2><Icon name="users" size={17} /> Guest list & manual check-in</h2>
              <Mono>{rows.length} OF {current!.registeredCount} REGISTERED</Mono>
            </div>
            <div className="table-controls">
              <div className="search-wrap compact">
                <Icon name="search" size={15} />
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search name, ID or Telegram handle…"
                />
              </div>
              <div className="guest-tabs">
                {(
                  [
                    ['all', `All (${attendees.length})`],
                    ['checked', `Checked In (${checkedIn.length})`],
                    ['not', `Not Arrived (${pending.length})`],
                    ['waitlist', `Waitlist (${current!.waitlistRoster.length})`],
                    ['screening', `Screening Pending (${screeningTickets.length})`],
                  ] as [GuestTab, string][]
                ).map(([id, label]) => (
                  <button key={id} className={tab === id ? 'is-active' : ''} onClick={() => setTab(id)}>
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {tab === 'waitlist' ? (
              <div className="guest-table">
                {current!.waitlistRoster.length === 0 ? (
                  <p className="hint">No one is waiting for a seat on this event.</p>
                ) : (
                  current!.waitlistRoster.map((w, i) => (
                    <div key={w.id} className="guest-row">
                      <Avatar name={w.name} color="#F97316" size={30} />
                      <div className="guest-name">
                        <strong>{w.name}</strong>
                        <span className="mono">{w.studentId} · {w.telegram}</span>
                      </div>
                      <span className="guest-prog">{w.programmeShort}</span>
                      <span className="status-chip is-waitlist">WAITLIST #{i + 1}</span>
                      <span className="guest-action mono">AUTO-PROMOTE</span>
                    </div>
                  ))
                )}
              </div>
            ) : tab === 'screening' ? (
              <div className="guest-table">
                {screeningTickets.length === 0 ? (
                  <p className="hint">No screening applications are waiting for review.</p>
                ) : (
                  screeningTickets.map((t) => {
                    const p = PERSONAS.find((x) => x.id === t.userId);
                    return (
                      <div key={t.ticketId} className="guest-row">
                        <Avatar name={p?.name ?? 'Applicant'} color={p?.color ?? '#2563EB'} size={30} />
                        <div className="guest-name">
                          <strong>{p?.name ?? 'Applicant'}</strong>
                          <span>{t.screeningAnswer || 'No answer provided'}</span>
                        </div>
                        <span className="status-chip is-pending">SCREENING PENDING</span>
                        <button
                          className="btn btn-primary btn-xs"
                          onClick={() =>
                            app.pushToast({
                              tone: 'success',
                              telegram: true,
                              title: 'Application approved',
                              message: `${p?.name ?? 'The student'} received a confirmed QR pass on Telegram.`,
                            })
                          }
                        >
                          Approve
                        </button>
                      </div>
                    );
                  })
                )}
              </div>
            ) : (
              <div className="guest-table">
                {visibleRows.length === 0 ? (
                  <p className="hint">No guests match this filter.</p>
                ) : (
                  visibleRows.map((a, i) => {
                    const checkedAt = current!.checkIns[a.id];
                    return (
                      <div key={a.id} className="guest-row">
                        <Avatar name={a.name} color={a.color} size={30} />
                        <div className="guest-name">
                          <strong>{a.name}{a.self ? ' (you)' : ''}</strong>
                          <span className="mono">
                            {a.self ? app.persona.studentId : `UDEA-24-${1000 + i}`} · {a.telegram}
                          </span>
                        </div>
                        <span className="guest-prog">{a.programmeShort}</span>
                        {checkedAt ? (
                          <span className="status-chip is-checked">
                            ✓ {new Date(checkedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        ) : (
                          <span className="status-chip is-away">NOT ARRIVED</span>
                        )}
                        {checkedAt ? (
                          <button className="btn btn-ghost btn-xs" onClick={() => app.undoCheckIn(current!.id, a.id)}>
                            Undo
                          </button>
                        ) : (
                          <button className="btn btn-primary btn-xs" onClick={() => app.checkInPerson(current!.id, a.id)}>
                            <Icon name="check" size={12} /> Check in
                          </button>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            )}
          </section>
        </>
      )}

      <section className="admin-queue">
        <div className="panel-head">
          <h2><Icon name="shield" size={17} /> Admin room & event approval queue</h2>
          <Mono>{pendingApprovals.length} PENDING</Mono>
        </div>
        {app.persona.role !== 'admin' ? (
          <div className="admin-locked">
            <div>
              <strong>{pendingApprovals.length} request{pendingApprovals.length === 1 ? '' : 's'} waiting for Campus Operations</strong>
              <p>Room requests from official student events are reviewed by Timur Alimov. Switch persona to approve them.</p>
            </div>
            <button className="btn btn-ghost btn-sm" onClick={() => app.setPersona('usr_3')}>
              Switch to Timur (Admin)
            </button>
          </div>
        ) : pendingApprovals.length === 0 ? (
          <p className="hint">All room requests are cleared. New official submissions from students land here instantly.</p>
        ) : (
          <div className="approval-grid">
            {pendingApprovals.map((e) => (
              <ApprovalCard key={e.id} event={e} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function ApprovalCard({ event }: { event: EventItem }) {
  const app = useApp();
  const room = ROOMS.find((r) => r.id === event.roomId);
  const conflicts = findRoomConflicts(app.state.events, event.roomId, event.date, event.startTime, event.endTime, event.id);
  const freeRooms = ROOMS.filter(
    (r) =>
      r.campus === event.campus &&
      r.kind !== 'online' &&
      r.id !== event.roomId &&
      findRoomConflicts(app.state.events, r.id, event.date, event.startTime, event.endTime, event.id).length === 0,
  );
  const [suggested, setSuggested] = useState(freeRooms[0]?.id ?? '');

  return (
    <div className="approval-card">
      <div className="approval-head">
        <div>
          <strong>{event.title}</strong>
          <span className="mono">{dayLabel(event.date)} • {event.startTime}–{event.endTime} • {event.hostName}</span>
        </div>
        <span className="badge badge-warn">PENDING</span>
      </div>
      <div className="approval-facts">
        <span className="mono">{room?.name}</span>
        <span className="mono">CAP {event.capacity}</span>
        <span className="mono">{event.language}</span>
      </div>
      <div className={`conflict-badge ${conflicts.length ? 'is-conflict' : 'is-free'}`}>
        <Icon name={conflicts.length ? 'x' : 'check'} size={14} />
        <span>
          {conflicts.length
            ? `Room conflict with “${conflicts[0].title}” (${conflicts[0].startTime}–${conflicts[0].endTime})`
            : 'Room free & requested equipment available'}
        </span>
      </div>
      <div className="equipment-chips">
        {event.equipmentRequested.map((eq) => (
          <span key={eq} className="equip-chip"><Icon name="check" size={11} /> {eq}</span>
        ))}
      </div>
      {freeRooms.length > 0 && (
        <div className="suggest-row">
          <select value={suggested} onChange={(e) => setSuggested(e.target.value)} aria-label="Suggested room">
            {freeRooms.map((r) => (
              <option key={r.id} value={r.id}>{r.name} · cap {r.capacity}</option>
            ))}
          </select>
          <button
            className="btn btn-ghost btn-xs"
            onClick={() => app.rejectEvent(event.id, suggested || freeRooms[0].id)}
          >
            Suggest room
          </button>
        </div>
      )}
      <div className="approval-actions">
        <button className="btn btn-primary btn-sm" onClick={() => app.approveEvent(event.id)}>
          <Icon name="check" size={14} /> Approve & Auto-Post to Telegram
        </button>
        <button
          className="btn btn-ghost btn-sm danger-text"
          onClick={async () => {
            const ok = await app.askConfirm({
              title: 'Reject this event?',
              message: `“${event.title}” will be removed from the approval queue and the organiser notified on Telegram.`,
              confirmLabel: 'Reject event',
              tone: 'danger',
            });
            if (ok) app.rejectEvent(event.id);
          }}
        >
          Reject
        </button>
      </div>
    </div>
  );
}
