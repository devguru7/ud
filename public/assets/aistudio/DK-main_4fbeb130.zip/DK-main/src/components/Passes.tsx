import React from 'react';
import { useApp } from '../lib/store';
import type { EventItem, Ticket } from '../types';
import { Avatar, Icon, Mono, SectionHeader, TicketQR, EmptyState } from './UI';
import { CLUBS, ROOMS } from '../lib/seed';
import { dayLabel, longDate, minutesFromTime, shortDate, isoDate } from '../lib/utils';

const BADGES: Record<string, string[]> = {
  usr_1: ['FinTech Explorer', 'Hackathon Finalist', 'Debate Speaker'],
  usr_2: ['Data Analytics Lead', 'Hackathon Mentor', 'Community Builder'],
  usr_3: ['Campus Operations', 'Room Approvals', 'Event Safety'],
};

export default function Passes() {
  const app = useApp();
  const persona = app.persona;
  const today = isoDate();

  const rows = app.state.tickets
    .filter((t) => t.userId === persona.id && t.status !== 'cancelled')
    .map((t) => ({ ticket: t, event: app.state.events.find((e) => e.id === t.eventId) }))
    .filter((r): r is { ticket: Ticket; event: EventItem } => Boolean(r.event))
    .sort((a, b) => `${a.event.date}${a.event.startTime}`.localeCompare(`${b.event.date}${b.event.startTime}`));

  const upcoming = rows.filter(({ event }) => event.date >= today && !event.past);
  const past = rows.filter(({ event }) => event.date < today || event.past);
  const attended = past.filter(({ ticket }) => ticket.status === 'checked_in').length;
  const xp = persona.xp + upcoming.length * 15;
  const goldTarget = 1000;
  const progress = Math.min(100, Math.round((xp / goldTarget) * 100));
  const badges = BADGES[persona.id] ?? ['Campus Explorer'];

  return (
    <div className="passes-view">
      <SectionHeader
        icon="ticket"
        title="My QR Passes & Student Passport"
        subtitle="Holographic passes, waitlist positions and your co-curricular record — all stored locally."
        action={
          <span className="mono subtle">
            {upcoming.length} ACTIVE PASS{upcoming.length === 1 ? '' : 'ES'}
          </span>
        }
      />

      <div className="passport-grid">
        <div className="passport-card">
          <div className="passport-top">
            <Avatar name={persona.name} color={persona.color} size={64} />
            <div className="passport-id">
              <span className="mono subtle">UDEA CO-CURRICULAR PASSPORT</span>
              <h2>{persona.name}</h2>
              <p>{persona.programme ?? persona.department}</p>
              <div className="passport-mono">
                <Mono>{persona.studentId}</Mono>
                <span className="dotsep" />
                <Mono>{persona.telegram}</Mono>
                {persona.year && (
                  <>
                    <span className="dotsep" />
                    <Mono>{persona.year}</Mono>
                  </>
                )}
              </div>
            </div>
            <div className="passport-score">
              <span className="score-value">{persona.reliabilityScore}%</span>
              <span className="mono">RELIABILITY</span>
              <em>{persona.reliabilityScore >= 95 ? 'Trusted Attendee' : 'Building trust'}</em>
            </div>
          </div>

          <div className="passport-stats">
            <div className="pstat">
              <span className="mono">CAMPUS XP</span>
              <strong>{xp}</strong>
              <em>+15 per RSVP</em>
            </div>
            <div className="pstat">
              <span className="mono">EVENTS ATTENDED</span>
              <strong>{attended}</strong>
              <em>verified check-ins</em>
            </div>
            <div className="pstat">
              <span className="mono">ACTIVE PASSES</span>
              <strong>{upcoming.length}</strong>
              <em>incl. waitlists</em>
            </div>
          </div>

          <div className="passport-badges">
            {badges.map((b) => (
              <span key={b} className="skill-badge">
                <Icon name="spark" size={12} /> {b}
              </span>
            ))}
          </div>

          <div className="gold-progress">
            <div className="gold-head">
              <span>
                <Icon name="spark" size={14} /> UDEA Gold Co-Curricular Diploma Supplement
              </span>
              <Mono>{xp} / {goldTarget} XP</Mono>
            </div>
            <div className="capacity-track">
              <div className="capacity-fill gold-fill" style={{ width: `${Math.max(progress, 4)}%` }} />
            </div>
            <p>{progress}% complete · attend {Math.max(0, 8 - attended)} more verified events this semester to qualify.</p>
          </div>
        </div>

        <div className="passport-side">
          <div className="mini-info-card">
            <span className="mono subtle">HOW PASSES WORK</span>
            <ul>
              <li><Icon name="qr" size={14} /> QR passes are cached offline — scanning works in basement halls.</li>
              <li><Icon name="bell" size={14} /> The bot checks 4h before start; confirm to lock your seat.</li>
              <li><Icon name="clock" size={14} /> Releasing a seat promotes waitlist #1 automatically.</li>
            </ul>
          </div>
          <button className="btn btn-primary btn-lg block" onClick={() => app.setView('explore')}>
            <Icon name="compass" size={16} /> Find your next event
          </button>
        </div>
      </div>

      <div className="pass-section">
        <div className="pass-section-head">
          <h2>Active passes</h2>
          <Mono>{upcoming.length} UPCOMING</Mono>
        </div>
        {upcoming.length === 0 ? (
          <EmptyState
            icon="ticket"
            title="No active passes yet"
            message="Claim a seat on any event and the holographic QR pass appears here instantly."
            action={<button className="btn btn-primary" onClick={() => app.setView('explore')}>Explore events</button>}
          />
        ) : (
          <div className="pass-list">
            {upcoming.map(({ ticket, event }) => (
              <PassCard key={ticket.ticketId} event={event} ticket={ticket} />
            ))}
          </div>
        )}
      </div>

      {past.length > 0 && (
        <div className="pass-section">
          <div className="pass-section-head">
            <h2>Attendance history & certificates</h2>
            <Mono>{past.length} RECORDS</Mono>
          </div>
          <div className="history-list">
            {past.map(({ ticket, event }) => (
              <div key={ticket.ticketId} className="history-row">
                <span className={`history-stripe cat-${event.category}`} />
                <div className="history-main">
                  <strong>{event.title}</strong>
                  <span className="mono">{dayLabel(event.date)} • {event.campus.toUpperCase()} • {ticket.qrHash}</span>
                </div>
                <span className={`badge ${ticket.status === 'checked_in' ? 'badge-success' : 'badge-muted'}`}>
                  {ticket.status === 'checked_in' ? '✓ ATTENDED' : ticket.status.toUpperCase()}
                </span>
                <button
                  className="btn btn-ghost btn-sm"
                  disabled={ticket.status !== 'checked_in'}
                  onClick={() => app.openCertificate(ticket.ticketId)}
                >
                  <Icon name="print" size={14} /> View & Print Certificate
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function PassCard({ event, ticket }: { event: EventItem; ticket: Ticket }) {
  const app = useApp();
  const room = ROOMS.find((r) => r.id === event.roomId);
  const club = CLUBS.find((c) => c.id === event.hostClubId);
  const hours = (minutesFromTime(event.endTime) - minutesFromTime(event.startTime)) / 60;
  const confirmed = ticket.confirmedAttendance4h;

  return (
    <article className={`pass cat-${event.category} ${ticket.status === 'waitlisted' ? 'is-waitlist' : ''}`}>
      <div className="pass-main">
        <div className="pass-head">
          <div className="pass-host">
            <Avatar name={club?.name ?? event.hostName} color={club?.color ?? '#525860'} size={22} />
            <span>{event.hostName}</span>
            {event.issueCertificate && <span className="badge badge-muted">🎓 CERTIFICATE</span>}
          </div>
          <span className={`pass-status ${ticket.status}`}>
            {ticket.status === 'waitlisted' ? 'WAITLISTED' : ticket.status === 'external_saved' ? 'EXTERNAL SAVED' : '✓ CONFIRMED'}
          </span>
        </div>

        <h3 className="pass-title">{event.title}</h3>

        <div className="pass-facts">
          <div>
            <Mono>DATE</Mono>
            <strong>{longDate(event.date)}</strong>
          </div>
          <div>
            <Mono>TIME</Mono>
            <strong>{event.startTime}–{event.endTime}</strong>
          </div>
          <div>
            <Mono>VENUE</Mono>
            <strong>{event.campus} · {room?.code}</strong>
          </div>
          <div>
            <Mono>LANGUAGE</Mono>
            <strong>{event.language}</strong>
          </div>
        </div>

        <div className="pass-tags">
          <span className={`badge cat-${event.category}`}>{event.category === 'fintech' ? 'FinTech' : event.category.toUpperCase()}</span>
          <span className="badge badge-muted">{event.eventType === 'peer_meetup' ? '⚡ PEER MEETUP' : '🏛️ OFFICIAL'}</span>
          <span className="badge badge-muted">{hours}h VERIFIED</span>
          {confirmed && <span className="badge badge-success">✓ ATTENDANCE CONFIRMED</span>}
          {ticket.screeningStatus === 'pending' && <span className="badge badge-warn">SCREENING PENDING</span>}
        </div>

        <div className="pass-actions">
          {ticket.status === 'confirmed' && !confirmed && (
            <button className="btn btn-primary btn-sm" onClick={() => app.confirmAttendance(ticket.ticketId)}>
              <Icon name="check" size={14} /> Confirm attendance
            </button>
          )}
          {ticket.status === 'waitlisted' && (
            <span className="waitlist-note">
              <Icon name="clock" size={14} /> Position #{ticket.waitlistPosition} · auto-promotion on seat release
            </span>
          )}
          {ticket.status === 'external_saved' && (
            <a className="btn btn-ghost btn-sm" href={event.externalUrl} target="_blank" rel="noreferrer">
              Open partner portal <Icon name="external" size={13} />
            </a>
          )}
          <button className="btn btn-ghost btn-sm" onClick={() => app.openEvent(event.id)}>
            Event details
          </button>
          <button
            className="btn btn-ghost btn-sm danger-text"
            onClick={async () => {
              const ok = await app.askConfirm({
                title: ticket.status === 'waitlisted' ? 'Leave the waitlist?' : 'Cancel this pass?',
                message:
                  ticket.status === 'waitlisted'
                    ? 'Your waitlist position is released. You can rejoin if seats remain.'
                    : 'Your seat is released and the first waitlisted student is promoted immediately.',
                confirmLabel: ticket.status === 'waitlisted' ? 'Leave waitlist' : 'Release seat',
                tone: 'danger',
              });
              if (ok) app.cancelTicket(ticket.ticketId);
            }}
          >
            {ticket.status === 'waitlisted' ? 'Leave waitlist' : 'Release seat'}
          </button>
        </div>
      </div>

      <div className="pass-stub">
        <div className="stub-notch notch-top" />
        <div className="stub-notch notch-bottom" />
        {ticket.status === 'external_saved' ? (
          <div className="stub-external">
            <Icon name="external" size={22} />
            <span className="mono">PARTNER<br />REGISTRATION</span>
          </div>
        ) : (
          <TicketQR
            value={`https://t.me/udea_pulse_bot/app?startapp=checkin_${event.id}_${ticket.qrHash}`}
            size={112}
          />
        )}
        <span className="stub-label mono">
          {ticket.status === 'waitlisted' ? `WAITLIST #${ticket.waitlistPosition}` : ticket.seatNumber ? `SEAT #${ticket.seatNumber}` : 'EXTERNAL'}
        </span>
        <span className="stub-hash mono">{ticket.qrHash}</span>
        <span className="stub-hint mono">SCAN AT DOOR</span>
      </div>
      <div className="pass-foil" aria-hidden="true" />
    </article>
  );
}
